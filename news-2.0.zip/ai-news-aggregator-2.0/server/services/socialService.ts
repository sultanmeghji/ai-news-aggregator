import { SocialPlatform } from "@shared/schema";

interface SocialPostRequest {
  content: string;
  platform: SocialPlatform;
  storyUrl?: string;
}

interface SocialPostResponse {
  success: boolean;
  postId?: string;
  error?: string;
}

export class SocialService {
  private twitterBearerToken: string;
  private linkedinAccessToken: string;
  private storage?: import('../storage').IStorage;

  constructor(storage?: import('../storage').IStorage) {
    this.twitterBearerToken = process.env.TWITTER_BEARER_TOKEN || '';
    this.linkedinAccessToken = process.env.LINKEDIN_ACCESS_TOKEN || '';
    this.storage = storage;
    
    if (!this.twitterBearerToken) {
      console.warn('Twitter Bearer Token not found. Twitter posting will be disabled.');
    }
    if (!this.linkedinAccessToken) {
      console.warn('LinkedIn Access Token not found. LinkedIn posting will be disabled.');
    }
  }

  async createSocialPilotPost(content: string, platform: SocialPlatform, storyUrl?: string): Promise<SocialPostResponse> {
    if (!this.socialPilotApiKey) {
      return { success: false, error: 'Social Pilot API key not configured' };
    }

    try {
      // Track API usage for accounts call
      if (this.storage) {
        await this.storage.incrementSocialPilotCalls(1);
      }

      // Get available social accounts using correct API format
      const accountsResponse = await fetch(`${this.socialPilotBaseUrl}/accounts?api_key=${this.socialPilotApiKey}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        }
      });

      if (!accountsResponse.ok) {
        const errorText = await accountsResponse.text();
        console.error('Social Pilot accounts error:', accountsResponse.status, errorText);
        return { 
          success: false, 
          error: `Failed to fetch accounts (${accountsResponse.status}): ${errorText}` 
        };
      }

      const accountsData = await accountsResponse.json();
      console.log('Social Pilot accounts response:', accountsData);

      // Handle different response structures
      const accounts = accountsData.data || accountsData.accounts || accountsData;
      
      if (!Array.isArray(accounts)) {
        return { success: false, error: 'No social accounts found in Social Pilot response' };
      }

      // Map platform names correctly
      const platformMapping: { [key: string]: string[] } = {
        'linkedin': ['linkedin', 'linkedin-company'],
        'twitter': ['twitter', 'x', 'twitter-x']
      };

      const platformVariants = platformMapping[platform.toLowerCase()] || [platform.toLowerCase()];
      
      // Find the first account matching the requested platform
      const targetAccount = accounts.find((account: any) => {
        const accountType = (account.type || account.provider || account.platform || '').toLowerCase();
        return platformVariants.some(variant => accountType.includes(variant));
      });

      if (!targetAccount) {
        const availablePlatforms = accounts.map((acc: any) => acc.type || acc.provider || acc.platform).join(', ');
        return { 
          success: false, 
          error: `No ${platform} account found. Available: ${availablePlatforms}` 
        };
      }

      console.log('Using account:', targetAccount);

      // Create the post with proper format
      const postData = {
        message: content,
        social_account_ids: [targetAccount.id],
        schedule_type: 'now',
        ...(storyUrl && { url: storyUrl })
      };

      // Track API usage for post creation
      if (this.storage) {
        await this.storage.incrementSocialPilotCalls(1);
      }

      const postResponse = await fetch(`${this.socialPilotBaseUrl}/posts?api_key=${this.socialPilotApiKey}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify(postData)
      });

      if (postResponse.ok) {
        const result = await postResponse.json();
        console.log('Social Pilot post created:', result);
        return { 
          success: true, 
          postId: result.data?.id || result.id || 'created'
        };
      } else {
        const errorText = await postResponse.text();
        console.error('Social Pilot post error:', postResponse.status, errorText);
        return { 
          success: false, 
          error: `Post creation failed (${postResponse.status}): ${errorText}` 
        };
      }
    } catch (error) {
      return { 
        success: false, 
        error: `Social Pilot posting failed: ${error instanceof Error ? error.message : 'Unknown error'}` 
      };
    }
  }

  async testConnection(): Promise<{ success: boolean; accounts?: any[]; error?: string }> {
    if (!this.socialPilotApiKey) {
      return { success: false, error: 'Social Pilot API key not configured' };
    }

    try {
      // Try the URL parameter approach for Social Pilot API
      const response = await fetch(`${this.socialPilotBaseUrl}/accounts?api_key=${this.socialPilotApiKey}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        }
      });

      if (!response.ok) {
        const errorText = await response.text();
        return { 
          success: false, 
          error: `API connection failed (${response.status}): ${errorText}` 
        };
      }

      const data = await response.json();
      const accounts = data.data || data.accounts || data;
      
      return { 
        success: true, 
        accounts: Array.isArray(accounts) ? accounts : []
      };
    } catch (error) {
      return { 
        success: false, 
        error: `Connection test failed: ${error instanceof Error ? error.message : 'Unknown error'}` 
      };
    }
  }

  // Legacy method names for backward compatibility
  async postToLinkedIn(content: string, storyUrl?: string): Promise<SocialPostResponse> {
    return this.createSocialPilotPost(content, 'linkedin', storyUrl);
  }

  async postToTwitter(content: string, storyUrl?: string): Promise<SocialPostResponse> {
    return this.createSocialPilotPost(content, 'twitter', storyUrl);
  }
}