# AI News Aggregator 2.0

## Quick Start

1. **Run setup script:**
   ```bash
   node setup.js
   ```

2. **Install dependencies:**
   ```bash
   npm install
   ```

3. **Edit .env file with your API keys:**
   - Get News API key from https://newsapi.org/
   - Get Anthropic API key from https://console.anthropic.com/

4. **Start the application:**
   ```bash
   npm run dev
   ```

5. **Open in browser:**
   ```
   http://localhost:5000
   ```

## Full Installation Guide

See `INSTALL_MAC.md` for complete macOS setup instructions from a fresh system.

## Features

- AI-powered news aggregation and summary generation
- Direct Twitter and LinkedIn posting
- Social media echo tracking
- Simple CSV file storage (no database required)
- Rate limiting and usage monitoring
- Modern React UI with real-time updates

## System Requirements

- Node.js 18 or higher
- macOS, Windows, or Linux
- API keys from News API and Anthropic

## Architecture

- **Frontend:** React 18 + TypeScript + Tailwind CSS
- **Backend:** Express.js + TypeScript
- **Storage:** CSV files (no database setup required)
- **AI:** Anthropic Claude for content generation
- **News:** News API for article fetching
- **Social:** Direct Twitter and LinkedIn API integration