# AI News Aggregator 2.0 - Mac Installation Guide

Complete setup instructions for macOS from a fresh system.

## Prerequisites

### 1. Install Homebrew (Package Manager)
Open Terminal and run:
```bash
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
```

### 2. Install Node.js
```bash
brew install node
```

Verify installation:
```bash
node --version  # Should show v18 or higher
npm --version   # Should show v9 or higher
```

## Installation Steps

### 1. Extract the Package
- Download `news-2.0.zip`
- Double-click to extract to your desired location (e.g., Desktop)
- Open Terminal and navigate to the folder:
```bash
cd ~/Desktop/ai-news-aggregator-2.0
```

### 2. Install Dependencies
```bash
npm install
```

### 3. Set Up Environment Variables
Copy the example environment file:
```bash
cp .env.example .env
```

Edit the `.env` file with your API keys:
```bash
open .env
```

Add your API keys:
```env
# Required: News API (get from https://newsapi.org/)
NEWS_API_KEY=your_actual_news_api_key_here

# Required: Anthropic Claude API (get from https://console.anthropic.com/)
ANTHROPIC_API_KEY=your_actual_anthropic_api_key_here

# Optional: Direct Social Media Integration
TWITTER_BEARER_TOKEN=your_actual_twitter_bearer_token_here
LINKEDIN_ACCESS_TOKEN=your_actual_linkedin_access_token_here
```

### 4. Get API Keys

#### News API (Required)
1. Go to https://newsapi.org/
2. Click "Get API Key"
3. Sign up for a free account
4. Copy your API key and paste it in `.env`

#### Anthropic Claude API (Required)
1. Go to https://console.anthropic.com/
2. Sign up for an account
3. Go to "API Keys" section
4. Create a new API key
5. Copy and paste it in `.env`

#### Twitter API (Optional)
1. Go to https://developer.twitter.com/
2. Apply for developer access
3. Create an app and get Bearer Token

#### LinkedIn API (Optional)
1. Go to https://developer.linkedin.com/
2. Create an app
3. Get Access Token through OAuth flow

### 5. Start the Application
```bash
npm run dev
```

You should see:
```
[express] serving on port 5000
```

### 6. Access the Application
Open your web browser and go to:
```
http://localhost:5000
```

## Troubleshooting

### Port Already in Use
If port 5000 is busy, change it in `.env`:
```env
PORT=3000
```

### Permission Errors
If you get permission errors:
```bash
sudo chown -R $(whoami) ~/.npm
```

### CSV Storage Issues
The app creates a `data/` directory automatically. If you see errors:
```bash
mkdir data
chmod 755 data
```

## Features

- AI-powered news aggregation and summary generation
- Direct Twitter and LinkedIn posting
- Social media echo tracking
- Simple CSV file storage (no database required)
- Rate limiting and usage monitoring
- Modern React UI with real-time updates

## Data Storage

All data is stored in CSV files in the `data/` directory:
- `stories.csv` - News stories and summaries
- `social_posts.csv` - Social media posting history
- `api_usage.csv` - Daily API usage tracking