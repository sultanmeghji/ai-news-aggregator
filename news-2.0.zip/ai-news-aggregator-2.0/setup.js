#!/usr/bin/env node

const fs = require('fs');

console.log('🚀 AI News Aggregator 2.0 Setup');
console.log('================================\n');

// Check if .env exists
if (!fs.existsSync('.env')) {
  console.log('📝 Creating .env file from template...');
  fs.copyFileSync('.env.example', '.env');
  console.log('✅ .env file created');
  console.log('\n⚠️  IMPORTANT: Edit .env file with your API keys before running npm run dev\n');
} else {
  console.log('✅ .env file already exists');
}

// Check if data directory exists
if (!fs.existsSync('data')) {
  console.log('📁 Creating data directory...');
  fs.mkdirSync('data', { recursive: true });
  console.log('✅ Data directory created');
} else {
  console.log('✅ Data directory already exists');
}

console.log('\n🎉 Setup complete!');
console.log('\nNext steps:');
console.log('1. Edit .env file with your API keys');
console.log('2. Run: npm install');
console.log('3. Run: npm run dev');
console.log('4. Open: http://localhost:5000');
